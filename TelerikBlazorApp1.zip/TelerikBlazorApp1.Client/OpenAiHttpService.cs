﻿using System.Net.Http.Json;
using TelerikBlazorApp1;
using TelerikBlazorApp1.Client;

public class OpenAiHttpService : IOpenAiService
{
    private readonly HttpClient httpClient;

    public OpenAiHttpService(HttpClient httpClient) => this.httpClient = httpClient;
    public async Task<string> MakeAiRequest(MyPrompt prompt)
    {
        var result = await httpClient.PostAsJsonAsync<MyPrompt>("/openai", prompt);
        var chat = await result.Content.ReadAsStringAsync();
        return chat;
    }
}