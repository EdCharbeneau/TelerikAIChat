﻿namespace TelerikBlazorApp1.Client
{
    public class MyPrompt
    {
        public string Prompt { get; set; } = "";
    }
}
