﻿using TelerikBlazorApp1.Client;

namespace TelerikBlazorApp1
{
    public class OpenAiService : IOpenAiService
    {
        public async Task<string> MakeAiRequest(MyPrompt prompt)
        {
            var api = new OpenAI_API.OpenAIAPI("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");
            var result = await api.Chat.CreateChatCompletionAsync(prompt.Prompt);
            return result.ToString();
        }
    }
}
